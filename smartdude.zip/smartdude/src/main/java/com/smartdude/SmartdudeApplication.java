package com.smartdude;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SmartdudeApplication {

	public static void main(String[] args) {
		SpringApplication.run(SmartdudeApplication.class, args);
	}

}
