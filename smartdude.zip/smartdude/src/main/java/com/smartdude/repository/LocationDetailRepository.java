package com.smartdude.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.smartdude.entity.LocationDetail;

public interface LocationDetailRepository extends JpaRepository<LocationDetail, Integer> {

}
